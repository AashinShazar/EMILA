/* ========================================
 *
 * Copyright YOUR COMPANY, THE YEAR
 * All Rights Reserved
 * UNPUBLISHED, LICENSED SOFTWARE.
 *
 * CONFIDENTIAL AND PROPRIETARY INFORMATION
 * WHICH IS THE PROPERTY OF your company.
 *
 * ========================================
*/
#include "project.h"

#define DESCR0              0
#define DESCR1              1
#define BUFFER_SIZE         16


CY_ISR(DmaDone)
{
    finishedDMA = 1u;
}

int main(void)
{
    uint8 DMA_1_Chan;
    uint8 DMA_1_TD[1u]={0u};
    char8 resultStr[16u];
    float res;
    
    for(;;)
    {
        /* Place your application code here. */
    }
}

/* [] END OF FILE */
